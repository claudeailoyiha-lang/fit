import 'package:flutter/material.dart';

void main() {
  runApp(const FitEmpireApp());
}

class FitEmpireApp extends StatelessWidget {
  const FitEmpireApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FitEmpire',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Poppins',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF9EF01A)),
        useMaterial3: true,
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 0;
  int _waterCups = 3;
  int _exercisesDone = 3;
  int _kcalBurned = 245;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildHomeTab(),
      _buildReportTab(),
      _buildMealsTab(),
      _buildProfileTab(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SafeArea(child: pages[_selectedIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (idx) => setState(() => _selectedIndex = idx),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.fitness_center), label: 'Asosiy'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Hisobot'),
          NavigationDestination(icon: Icon(Icons.restaurant_menu), label: 'Taomlar'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }

  Widget _buildHomeTab() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Vazn yo\'qotish', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const Text('O\'zgarishlar bugundan boshlanadi!', style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFFE9F5DB),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            children: [
              const Text('Bu hafta', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              const Text('00:15:20', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(children: [Text('$_exercisesDone', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const Text('Mashq')]),
                  Column(children: [Text('$_kcalBurned', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const Text('KCal')]),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text('Siz uchun maxsus', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.25,
          children: [
            _workoutCard('Bel mashqlari', '1 Hafta', 120),
            _workoutCard('Qorin press', '15 Kun', 190),
            _workoutCard('Qo\'llar', '20 Kun', 145),
            _workoutCard('Oyoqlar', '15 Kun', 210),
          ],
        ),
      ],
    );
  }

  Widget _workoutCard(String title, String duration, int kcal) {
    return InkWell(
      onTap: () {
        setState(() {
          _exercisesDone++;
          _kcalBurned += kcal;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$title bajarildi! +$kcal KCal')),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF9EF01A),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(duration, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReportTab() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Hisobot va BMI Tahlili', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: const Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('BMI (Tana massasi indeksi): 22.8 kg/m²', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('Holat: Normal vazn', style: TextStyle(color: Colors.green, fontWeight: FontWeight.w600)),
                SizedBox(height: 8),
                Text('Kunlik BMR (Harris-Benedict): 1426 KCal'),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMealsTab() {
    final meals = [
      {'title': 'Sabzavotli omlet', 'sub': 'Nonushta • 161 KCal • 8.5g oqsil'},
      {'title': 'Olma va yong\'oqli suli bo\'tqasi', 'sub': 'Nonushta • 215 KCal • 7.2g oqsil'},
      {'title': 'Karam va sabzili parhez sho\'rva', 'sub': 'Tushlik • 140 KCal • 5.8g oqsil'},
      {'title': 'Sabzavot sousli kartoshka', 'sub': 'Kechki ovqat • 195 KCal • 6.4g oqsil'},
    ];
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Sog\'lom ovqatlanish', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const Text('Har kuni bittadan olma', style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 16),
        ...meals.map((m) => Card(
              margin: const EdgeInsets.only(bottom: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              child: ListTile(
                leading: const CircleAvatar(backgroundColor: Color(0xFFE9F5DB), child: Icon(Icons.restaurant, color: Colors.green)),
                title: Text(m['title']!, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(m['sub']!),
              ),
            )),
      ],
    );
  }

  Widget _buildProfileTab() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Profil', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const CircleAvatar(radius: 36, child: Icon(Icons.person, size: 36)),
                const SizedBox(height: 12),
                const Text('Sevaraxon Abduxalilova', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const Text('22 yosh • 165 sm • 62 kg', style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () => setState(() => _waterCups = (_waterCups - 1).clamp(0, 12)),
                      icon: const Icon(Icons.remove_circle_outline),
                    ),
                    Text('💧 Suv: $_waterCups / 8 stakan', style: const TextStyle(fontWeight: FontWeight.bold)),
                    IconButton(
                      onPressed: () => setState(() => _waterCups = (_waterCups + 1).clamp(0, 12)),
                      icon: const Icon(Icons.add_circle_outline),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
